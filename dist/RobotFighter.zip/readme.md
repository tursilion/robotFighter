19900801

This was a game I created way back in 1985 or 1986 for the TI. I ported it to C around 1990 when I was starting to learn that. I also ported it to the Apple 2, but that's way lost.

Originally, I saw it as a Mass Murderer game - hit the victims and they leave a body behind. If a policeman finds a body, then they all begin to chase you - otherwise you're safe.

When I grew up a little I realized how horrible that was, and changed it to Robot Fighter. My buddy's brother Alan drew new title graphics for me, and I rebranded the text in the game - though nothing else changed.

Originally shipped on disk, both versions are now combined into a single 32k cartridge. Only Robot Fighter shows on the selection page, but if you hold SPACE after selecting it, you will get Mass Murderer instead. For reasons I can not remember, holding A after making your selection will show Rainbow Dash in a clown suit. ;)

It appears I only have the original C source code anymore, so that's also what's in here, plus the hacks for the cartridge loader.

I've also included a flyer created back in the day by my friend Gord - which we did mostly to celebrate his getting a then-uncommon laser printer.

To run the Editor/Assembler versions, copy the ROBO1/2/3 or MASSMURD/E/F files to disk, as well as the corresponding _P image file. Run EA#5 DSK1.ROBO1 or DSK1.MASSMURD. These files are also on the enclosed disk image.

